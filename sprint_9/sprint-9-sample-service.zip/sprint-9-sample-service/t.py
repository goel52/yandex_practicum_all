import logging

# create logger
logger = logging.getLogger('simple_example')


# 'application' code
logger.debug('debug message')
logger.info('info message')
logger.warning('warn message')
logger.error('error message')
logger.critical('critical message')
