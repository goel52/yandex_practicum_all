USER_HOST = '158.160.107.90' # укажите свой хост
TOPIC_NAME = 'student.topic.cohort31.mila1-7-5' # укажите название топика student.topic.cohort<номер когорты>.<username>